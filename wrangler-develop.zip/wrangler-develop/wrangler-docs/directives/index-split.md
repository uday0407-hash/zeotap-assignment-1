# Indexsplit

The INDEXSPLIT directive splits a string at a given index into two substrings.


## Deprecated

Use the [SPLIT-TO-COLUMNS](split-to-columns.md) or
[PARSE-AS-FIXED-LENGTH](fixed-length-parser.md) directives instead.
