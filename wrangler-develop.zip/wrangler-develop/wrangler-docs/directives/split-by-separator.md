# Split By Separator

The SPLIT-BY-SEPARATOR directive splits a column based on a separator into two columns.

## Deprecated

Use the [SPLIT-TO-COLUMNS](split-to-columns.md) directive instead.
